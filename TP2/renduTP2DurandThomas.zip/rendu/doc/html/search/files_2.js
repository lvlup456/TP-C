var searchData=
[
  ['nbr_2ec',['nbr.c',['../nbr_8c.html',1,'']]]
];
