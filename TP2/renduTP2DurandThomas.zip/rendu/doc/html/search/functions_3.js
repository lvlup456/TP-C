var searchData=
[
  ['nbr',['nbr',['../nbr_8c.html#a9325a8fa4811954cebfb0b7d62862d5d',1,'nbr.c']]]
];
