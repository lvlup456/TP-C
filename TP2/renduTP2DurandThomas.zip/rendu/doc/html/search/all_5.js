var searchData=
[
  ['richeter',['richeter',['../richter_8c.html#a44b2558e4739113c9f9fa26989c7a2a7',1,'richter.c']]],
  ['richter_2ec',['richter.c',['../richter_8c.html',1,'']]]
];
