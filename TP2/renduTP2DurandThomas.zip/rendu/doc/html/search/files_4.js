var searchData=
[
  ['richter_2ec',['richter.c',['../richter_8c.html',1,'']]]
];
