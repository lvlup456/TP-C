#ifndef __BANQUE_H_
#define __BANQUE_H_

void banque();

#endif