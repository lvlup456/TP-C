#ifndef __NBR_H_
#define __NBR_H_

int nbr();

#endif

