#ifndef __PREDICTION_H_
#define __PREDICTION_H_

int prediction();


#endif