#ifndef __RICHETER_H_
#define __RICHETER_H_

void richeter();


#endif