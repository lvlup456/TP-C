#ifndef __MAXMIN_H_
#define __MAXMIN_H_

int maxMin();


#endif