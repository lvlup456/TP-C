#ifndef __SAISIRPERSONNE_H_
#define __SAISIRPERSONNE_H_

int saisirPersonne();

#endif