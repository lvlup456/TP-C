#ifndef __DIVENTIER_H_
#define __DIVENTIER_H_

int divEntier();

#endif