#ifndef __SQRT_H_
#define __SQRT_H_

float methodeNewton(int n);
float methodeHalley(int n);
float methodeTheon(int n);

#endif